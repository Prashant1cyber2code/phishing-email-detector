# Phishing-email-detection
To classify Phishing Emails based on:

1.Email Header Analysis-Message id - N gram analysis of RHS of Message id.

2.Text content - Classify emails using text based on word frequency and also based on semantic analysis 

3.Phishing URL detection based on features in URL like length of URL, presence of @ symbol, prefix and suffix separated by '-' in domain names  ,presence of IP address, presence of redirection "//"

