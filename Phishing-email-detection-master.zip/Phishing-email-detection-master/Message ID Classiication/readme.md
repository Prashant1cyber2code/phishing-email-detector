Knowledge of message-id part will help to identify spoofed emails, source host, email log file analysis and time.
details.

Steps 

Dataset Preparation

Message ID extraction

Preprocessing

Finding n-gram frequency

Classification
