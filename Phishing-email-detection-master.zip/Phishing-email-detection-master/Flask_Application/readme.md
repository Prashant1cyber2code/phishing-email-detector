Text Classifictaion and URL Classification is integrated. Flask Application is used.
Emails are collected from Gmail.
User Interface
Frontend: Html,css,bootstrap
Backend: Python flask
Database: Sqlite3

Using imaplib library the latest email from the gmail account is got.
For that we have to specify the email id and password.
